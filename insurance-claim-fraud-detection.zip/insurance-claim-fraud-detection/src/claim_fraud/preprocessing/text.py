"""Text cleaning for claim narratives."""
import re


def clean_text(text):
    text = str(text).lower()
    text = re.sub(r"http\S+|www\.\S+", " ", text)
    text = re.sub(r"\d+", " 0 ", text)  # keep a "number was here" signal
    text = re.sub(r"[^a-z0-9!?.,' ]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()
