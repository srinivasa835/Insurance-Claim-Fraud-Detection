"""TF-IDF + hand-crafted-feature model: fit, transform and predict from one bundle."""
import joblib
import numpy as np
from scipy.sparse import csr_matrix, hstack
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

from claim_fraud.preprocessing.features import FEATURE_NAMES, build_matrix
from claim_fraud.preprocessing.text import clean_text


def fit_bundle(train_texts, train_labels, min_df=2, max_features=30000):
    """Fit TF-IDF, feature scaler and logistic regression on the training split only."""
    tfidf = TfidfVectorizer(ngram_range=(1, 2), min_df=min_df, max_features=max_features, sublinear_tf=True)
    scaler = StandardScaler()
    tfidf.fit([clean_text(t) for t in train_texts])
    scaler.fit(build_matrix(train_texts).values)
    bundle = {"tfidf": tfidf, "scaler": scaler, "model": None}
    X = transform(bundle, train_texts)
    bundle["model"] = LogisticRegression(max_iter=2000, class_weight="balanced").fit(X, train_labels)
    return bundle


def transform(bundle, texts):
    texts = list(texts)
    x_text = bundle["tfidf"].transform([clean_text(t) for t in texts])
    extra = bundle["scaler"].transform(build_matrix(texts).values)
    return hstack([x_text, csr_matrix(extra)]).tocsr()


def predict_proba(bundle, texts):
    """Probability of fraud for each narrative."""
    return bundle["model"].predict_proba(transform(bundle, texts))[:, 1]


def feature_names(bundle):
    return list(bundle["tfidf"].get_feature_names_out()) + FEATURE_NAMES


def save_bundle(bundle, path):
    joblib.dump(bundle, path)


def load_bundle(path):
    return joblib.load(path)
