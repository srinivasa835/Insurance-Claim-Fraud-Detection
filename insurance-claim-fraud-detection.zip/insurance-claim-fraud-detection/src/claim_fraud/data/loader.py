"""Loading and splitting claim-narrative datasets.

Expected CSV: one row per claim with a free-text narrative column and a binary
label column (1 = fraudulent, 0 = genuine). Column names are configurable.
"""
import pandas as pd
from sklearn.model_selection import train_test_split

SEED = 42
_POSITIVE = {"1", "y", "yes", "true", "fraud", "fraudulent"}


def load_csv(path, text_col="narrative", label_col="fraud"):
    """Read a CSV and return a DataFrame with columns `narrative` and `fraud` (0/1)."""
    df = pd.read_csv(path)
    missing = [c for c in (text_col, label_col) if c not in df.columns]
    if missing:
        raise ValueError(f"Column(s) {missing} not found. Available columns: {list(df.columns)}")
    df = df.rename(columns={text_col: "narrative", label_col: "fraud"})[["narrative", "fraud"]]
    df = df.dropna().drop_duplicates(subset="narrative")
    df["fraud"] = df["fraud"].map(lambda v: 1 if str(v).strip().lower() in _POSITIVE else 0)
    return df.reset_index(drop=True)


def split(df, test_size=0.2, val_size=0.1, seed=SEED):
    """Stratified train/validation/test split (default 70/10/20)."""
    train_val, test = train_test_split(df, test_size=test_size, stratify=df["fraud"], random_state=seed)
    train, val = train_test_split(
        train_val, test_size=val_size / (1 - test_size), stratify=train_val["fraud"], random_state=seed
    )
    return train.reset_index(drop=True), val.reset_index(drop=True), test.reset_index(drop=True)


def get_dataframe(data=None, synthetic=False, text_col="narrative", label_col="fraud"):
    """Single entry point used by every CLI: real CSV, or demo data with --synthetic."""
    if synthetic:
        from claim_fraud.data.synthetic import make_synthetic_dataset
        return make_synthetic_dataset()
    if not data:
        raise ValueError("Provide --data <csv> or use --synthetic for demo data.")
    return load_csv(data, text_col, label_col)
