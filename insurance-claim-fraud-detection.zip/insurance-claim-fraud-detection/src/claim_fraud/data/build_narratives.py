"""Turn the tabular Kaggle Insurance Claim Fraud file (insurance_claims.csv) into claim narratives.

The public file has no free-text column, so each claim's recorded fields are written out
as a short narrative in plain English. The fraud label is never used to build the text.
Exact amounts are converted to descriptive bands (low / moderate / high / very high) so
the text models can read them.

Usage:
    python -m claim_fraud.data.build_narratives --raw data/insurance_claims.csv --out data/claims.csv
"""
import argparse

import pandas as pd


def band(value, cuts, words):
    for c, w in zip(cuts, words):
        if value <= c:
            return w
    return words[-1]


def time_of_day(h):
    if h < 6:
        return "in the early hours of the night"
    if h < 12:
        return "in the morning"
    if h < 18:
        return "in the afternoon"
    return "in the evening"


def unknown(v, fallback="not stated"):
    return fallback if str(v).strip() in {"?", "nan", ""} else str(v).strip()


def narrative(r):
    total = band(r.total_claim_amount, [30000, 55000, 70000], ["low", "moderate", "high", "very high"])
    vehicle = band(r.vehicle_claim, [25000, 45000, 55000], ["small", "moderate", "large", "very large"])
    injury = band(r.injury_claim, [2000, 7000, 12000], ["small", "moderate", "large", "very large"])
    prop = band(r.property_claim, [2000, 7000, 12000], ["small", "moderate", "large", "very large"])
    tenure = band(r.months_as_customer, [100, 250, 400], ["a new", "a fairly new", "a long-standing", "a very long-standing"])
    veh_age = 2015 - int(r.auto_year)

    parts = [
        f"The insured, a {int(r.age)} year old {r.insured_occupation.replace('-', ' ')} and {tenure} customer, "
        f"reported a {r.incident_type.lower()} {time_of_day(r.incident_hour_of_the_day)} in {r.incident_city}, {r.incident_state}.",
        f"The vehicle was a {int(r.auto_year)} {r.auto_make} {r.auto_model}, about {veh_age} years old.",
        f"The damage was described as {r.incident_severity.lower()}.",
        f"The collision type was {unknown(r.collision_type, 'not applicable').lower()}.",
        f"{int(r.number_of_vehicles_involved)} vehicle{'s' if r.number_of_vehicles_involved != 1 else ''} "
        f"and {int(r.witnesses)} witness{'es' if r.witnesses != 1 else ''} were involved, with "
        f"{int(r.bodily_injuries)} bodily injur{'ies' if r.bodily_injuries != 1 else 'y'}.",
        f"Authorities contacted: {unknown(r.authorities_contacted, 'none').lower()}.",
        f"A police report was {unknown(r.police_report_available).lower()}.",
        f"Property damage was {unknown(r.property_damage).lower()}.",
        f"The insured's hobby is {r.insured_hobbies.replace('-', ' ')}.",
        f"The total claim is {total}, with {vehicle} vehicle damage, {injury} injury and {prop} property components.",
    ]
    return " ".join(parts)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default="data/insurance_claims.csv")
    ap.add_argument("--out", default="data/claims.csv")
    args = ap.parse_args()

    raw = pd.read_csv(args.raw)
    out = pd.DataFrame({
        "narrative": [narrative(r) for r in raw.itertuples(index=False)],
        "fraud": (raw["fraud_reported"].str.upper() == "Y").astype(int),
    })
    out.to_csv(args.out, index=False)
    print(f"wrote {len(out)} narratives to {args.out}; fraud rate {out['fraud'].mean():.2%}")
    print("example:", out.iloc[0]["narrative"])


if __name__ == "__main__":
    main()
