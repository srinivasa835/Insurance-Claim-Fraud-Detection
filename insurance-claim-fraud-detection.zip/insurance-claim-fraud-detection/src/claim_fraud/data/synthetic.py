"""Synthetic demo narratives.

ONLY for checking that the pipeline runs. The classes are trivially separable, so
metrics on this data mean nothing - never report them as results.
"""
import random

import pandas as pd

_GENUINE = [
    "I was driving home on {road} when another vehicle struck the rear of my car at a red light.",
    "The accident happened around {time}. I called the police and they filed a report.",
    "My car sustained damage to the rear bumper and tail lamp. I have attached the repair estimate.",
    "A witness stayed at the scene and gave their contact details to the officer.",
    "I took photographs of both vehicles and exchanged insurance details with the other driver.",
    "The repair shop inspected the car and confirmed the damage matches the collision.",
    "No one was seriously hurt, though I visited the clinic the next day as a precaution.",
]
_FRAUD = [
    "My car was totally destroyed, everything is gone, the loss is huge and I need payment urgently!",
    "It happened late at night, nobody saw anything, there was no one around and no cameras.",
    "I lost my expensive jewellery, laptop and phone in the same incident, all brand new.",
    "I cannot remember the exact place but the damage is very serious and costs a lot.",
    "I was hurt badly, the injury is severe, I need the maximum amount immediately.",
    "The car was stolen and later found burnt, I have no receipts but it was worth a lot.",
    "Please settle my claim fast, I will not provide more documents, the loss is total!",
]
_ROADS = ["NH16", "Main Road", "Ring Road", "MG Road", "Bypass Road"]
_TIMES = ["8 am", "6 pm", "noon", "9 pm", "7:30 am"]


def make_synthetic_dataset(n=1500, fraud_rate=0.3, seed=42):
    rng = random.Random(seed)
    rows = []
    for _ in range(n):
        is_fraud = rng.random() < fraud_rate
        pool = _FRAUD if is_fraud else _GENUINE
        k = rng.randint(3, 6)
        sents = rng.choices(pool, k=k) if is_fraud else rng.sample(pool, k=min(k, len(pool)))
        if rng.random() < 0.25:  # label noise: one sentence from the other class
            sents.append(rng.choice(_GENUINE if is_fraud else _FRAUD))
        text = " ".join(s.format(road=rng.choice(_ROADS), time=rng.choice(_TIMES)) for s in sents)
        rows.append((text, int(is_fraud)))
    return pd.DataFrame(rows, columns=["narrative", "fraud"])
