"""Fine-tune RoBERTa for claim-narrative fraud classification.

A GPU is strongly recommended (free Colab / Kaggle T4 works).

    python -m claim_fraud.training.train_roberta --data data/claims.csv --epochs 4 --max-len 256
    python -m claim_fraud.training.train_roberta --synthetic --epochs 1      # quick check

Narratives longer than --max-len tokens are truncated (RoBERTa supports at most 512).
"""
import argparse
import json
import os

import numpy as np
import torch
from sklearn.utils.class_weight import compute_class_weight
from torch.utils.data import DataLoader, Dataset
from transformers import AutoModelForSequenceClassification, AutoTokenizer, get_linear_schedule_with_warmup

from claim_fraud.data.loader import SEED, get_dataframe, split
from claim_fraud.evaluation.metrics import plot_curves, save_evaluation


class ClaimDataset(Dataset):
    def __init__(self, texts, labels, tok, max_len):
        self.enc = tok(list(texts), truncation=True, padding="max_length",
                       max_length=max_len, return_tensors="pt")
        self.labels = torch.tensor(list(labels), dtype=torch.long)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, i):
        return {"input_ids": self.enc["input_ids"][i],
                "attention_mask": self.enc["attention_mask"][i],
                "labels": self.labels[i]}


def run_epoch(model, loader, device, loss_fn, optimizer=None, scheduler=None):
    train = optimizer is not None
    model.train(train)
    total_loss, correct, n = 0.0, 0, 0
    probs, preds = [], []
    with torch.set_grad_enabled(train):
        for batch in loader:
            batch = {k: v.to(device) for k, v in batch.items()}
            logits = model(input_ids=batch["input_ids"], attention_mask=batch["attention_mask"]).logits
            loss = loss_fn(logits, batch["labels"])
            if train:
                optimizer.zero_grad(); loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step(); scheduler.step()
            pred = logits.argmax(-1)
            total_loss += loss.item() * len(pred)
            correct += (pred == batch["labels"]).sum().item(); n += len(pred)
            probs.extend(torch.softmax(logits, dim=-1)[:, 1].detach().cpu().numpy())
            preds.extend(pred.cpu().numpy())
    return total_loss / n, correct / n, np.array(preds), np.array(probs)


def main(argv=None):
    ap = argparse.ArgumentParser(description="Fine-tune RoBERTa for claim fraud detection")
    ap.add_argument("--data"); ap.add_argument("--text-col", default="narrative")
    ap.add_argument("--label-col", default="fraud"); ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--model", default="roberta-base")
    ap.add_argument("--epochs", type=int, default=4); ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--max-len", type=int, default=256); ap.add_argument("--lr", type=float, default=2e-5)
    ap.add_argument("--out", default="results")
    a = ap.parse_args(argv)

    torch.manual_seed(SEED)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("device:", device)

    df = get_dataframe(a.data, a.synthetic, a.text_col, a.label_col)
    train, val, test = split(df)
    print(f"train={len(train)} val={len(val)} test={len(test)} fraud_rate={df['fraud'].mean():.2%}")

    tok = AutoTokenizer.from_pretrained(a.model)
    loader = lambda f, shuffle: DataLoader(ClaimDataset(f["narrative"], f["fraud"], tok, a.max_len),
                                           batch_size=a.batch_size, shuffle=shuffle)
    tr, va, te = loader(train, True), loader(val, False), loader(test, False)

    model = AutoModelForSequenceClassification.from_pretrained(a.model, num_labels=2).to(device)
    w = compute_class_weight("balanced", classes=np.array([0, 1]), y=train["fraud"].values)
    loss_fn = torch.nn.CrossEntropyLoss(weight=torch.tensor(w, dtype=torch.float).to(device))
    optimizer = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=0.01)
    total = len(tr) * a.epochs
    scheduler = get_linear_schedule_with_warmup(optimizer, int(0.1 * total), total)

    hist = {"train_loss": [], "val_loss": [], "train_acc": [], "val_acc": []}
    best_val, best_state = -1.0, None
    for ep in range(1, a.epochs + 1):
        tl, ta, _, _ = run_epoch(model, tr, device, loss_fn, optimizer, scheduler)
        vl, vacc, _, _ = run_epoch(model, va, device, loss_fn)
        for k, v in zip(hist, (tl, vl, ta, vacc)):
            hist[k].append(v)
        print(f"epoch {ep}: train_loss={tl:.4f} train_acc={ta:.4f} val_loss={vl:.4f} val_acc={vacc:.4f}")
        if vacc > best_val:
            best_val = vacc
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

    model.load_state_dict(best_state)
    plot_curves(hist, "roberta", a.out)
    _, _, pred, prob = run_epoch(model, te, device, loss_fn)
    metrics = save_evaluation("roberta", test["fraud"].values, pred, prob, test["narrative"].values, a.out)
    print({k: round(v, 4) for k, v in metrics.items()})

    folder = os.path.join(a.out, "models", "roberta")
    os.makedirs(folder, exist_ok=True)
    model.save_pretrained(folder); tok.save_pretrained(folder)
    json.dump({"base_model": a.model, "max_len": a.max_len}, open(os.path.join(folder, "claim_fraud_config.json"), "w"))


if __name__ == "__main__":
    main()
