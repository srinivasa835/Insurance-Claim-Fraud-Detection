"""TF-IDF + logistic regression training.

    python -m claim_fraud.training.train_tfidf --data data/claims.csv
    python -m claim_fraud.training.train_tfidf --synthetic      # demo data only
"""
import argparse
import os

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss

from claim_fraud.data.loader import get_dataframe, split
from claim_fraud.evaluation.metrics import plot_curves, save_evaluation
from claim_fraud.explainability.tfidf_terms import export_top_terms
from claim_fraud.models import tfidf_model as T


def learning_curve(bundle, train, val):
    """Loss / accuracy against training-set size (the classical model has no epochs)."""
    X_tr, X_va = T.transform(bundle, train["narrative"]), T.transform(bundle, val["narrative"])
    hist = {"train_loss": [], "val_loss": [], "train_acc": [], "val_acc": []}
    for frac in (0.2, 0.4, 0.6, 0.8, 1.0):
        n = max(int(len(train) * frac), 10)
        m = LogisticRegression(max_iter=2000, class_weight="balanced").fit(X_tr[:n], train["fraud"][:n])
        hist["train_loss"].append(log_loss(train["fraud"][:n], m.predict_proba(X_tr[:n]), labels=[0, 1]))
        hist["val_loss"].append(log_loss(val["fraud"], m.predict_proba(X_va), labels=[0, 1]))
        hist["train_acc"].append(m.score(X_tr[:n], train["fraud"][:n]))
        hist["val_acc"].append(m.score(X_va, val["fraud"]))
    return hist


def main(argv=None):
    ap = argparse.ArgumentParser(description="Train the TF-IDF + LogReg baseline")
    ap.add_argument("--data"); ap.add_argument("--text-col", default="narrative")
    ap.add_argument("--label-col", default="fraud"); ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--out", default="results")
    a = ap.parse_args(argv)

    df = get_dataframe(a.data, a.synthetic, a.text_col, a.label_col)
    train, val, test = split(df)
    print(f"train={len(train)} val={len(val)} test={len(test)} fraud_rate={df['fraud'].mean():.2%}")

    bundle = T.fit_bundle(train["narrative"], train["fraud"])
    plot_curves(learning_curve(bundle, train, val), "tfidf_logreg_learning_curve", a.out)

    prob = T.predict_proba(bundle, test["narrative"])
    pred = (prob >= 0.5).astype(int)
    metrics = save_evaluation("tfidf_logreg", test["fraud"].values, pred, prob, test["narrative"].values, a.out)
    print({k: round(v, 4) for k, v in metrics.items()})

    export_top_terms(bundle, os.path.join(a.out, "explainability"))
    os.makedirs(os.path.join(a.out, "models"), exist_ok=True)
    T.save_bundle(bundle, os.path.join(a.out, "models", "tfidf_logreg.joblib"))


if __name__ == "__main__":
    main()
