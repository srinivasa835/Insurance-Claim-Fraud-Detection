"""Explainability: which words and signals push a claim towards 'fraud'."""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from claim_fraud.models.tfidf_model import feature_names


def top_terms(bundle, k=20):
    names = np.array(feature_names(bundle))
    coef = bundle["model"].coef_[0]
    order = np.argsort(coef)
    fraud_idx, genuine_idx = order[::-1][:k], order[:k]
    return pd.DataFrame({
        "fraud_indicator": names[fraud_idx], "fraud_weight": coef[fraud_idx].round(4),
        "genuine_indicator": names[genuine_idx], "genuine_weight": coef[genuine_idx].round(4),
    })


def export_top_terms(bundle, out_dir, k=20):
    os.makedirs(out_dir, exist_ok=True)
    df = top_terms(bundle, k)
    df.to_csv(os.path.join(out_dir, "tfidf_top_terms.csv"), index=False)

    fig, ax = plt.subplots(1, 2, figsize=(10, 5.5))
    ax[0].barh(df["fraud_indicator"][::-1], df["fraud_weight"][::-1], color="#c0392b")
    ax[0].set_title("Strongest fraud indicators")
    ax[1].barh(df["genuine_indicator"][::-1], df["genuine_weight"][::-1].abs(), color="#2471a3")
    ax[1].set_title("Strongest genuine indicators (|weight|)")
    for a in ax:
        a.set_xlabel("Logistic regression weight")
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "tfidf_top_terms.png"), dpi=200)
    plt.close(fig)
    return df
