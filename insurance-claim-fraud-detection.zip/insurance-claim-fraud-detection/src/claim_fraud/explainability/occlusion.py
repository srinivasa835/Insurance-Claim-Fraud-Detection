"""Sentence-occlusion explanations: how much does the fraud probability drop when a
sentence is removed? Works with any model through a `predict_fn(list_of_texts) -> probs`.

    python -m claim_fraud.explainability.occlusion --weights results/models/tfidf_logreg.joblib \
        --text "My car was destroyed! I need payment urgently!"
"""
import argparse
import re

import pandas as pd


def split_sentences(text):
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", str(text).strip()) if s.strip()]


def sentence_occlusion(predict_fn, text):
    """Return a DataFrame: sentence, fraud_probability_without, importance (= full - without)."""
    sents = split_sentences(text)
    if not sents:
        return pd.DataFrame(columns=["sentence", "prob_without", "importance"])
    variants = [" ".join(sents[:i] + sents[i + 1:]) or "." for i in range(len(sents))]
    probs = predict_fn([" ".join(sents)] + variants)
    full, without = float(probs[0]), [float(p) for p in probs[1:]]
    return pd.DataFrame({
        "sentence": sents,
        "prob_without": [round(p, 4) for p in without],
        "importance": [round(full - p, 4) for p in without],
    }).sort_values("importance", ascending=False).reset_index(drop=True).assign(full_probability=round(full, 4))


def main(argv=None):
    from claim_fraud.evaluation.inference import load_predictor

    ap = argparse.ArgumentParser(description="Explain a prediction by sentence occlusion")
    ap.add_argument("--weights", required=True); ap.add_argument("--text", required=True)
    ap.add_argument("--max-len", type=int, default=256)
    a = ap.parse_args(argv)
    predict_fn = load_predictor(a.weights, a.max_len)
    print(sentence_occlusion(predict_fn, a.text).to_string(index=False))


if __name__ == "__main__":
    main()
