"""Evaluate a trained model on the held-out test split.

The split is deterministic (seed 42), so passing the same data file as training
reproduces exactly the same 20% test set.

    python -m claim_fraud.evaluation.evaluate --weights results/models/tfidf_logreg.joblib --data data/claims.csv
"""
import argparse
import os

from claim_fraud.data.loader import get_dataframe, split
from claim_fraud.evaluation.inference import load_predictor
from claim_fraud.evaluation.metrics import save_evaluation


def main(argv=None):
    ap = argparse.ArgumentParser(description="Evaluate a trained model on the test split")
    ap.add_argument("--weights", required=True)
    ap.add_argument("--data"); ap.add_argument("--text-col", default="narrative")
    ap.add_argument("--label-col", default="fraud"); ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--name"); ap.add_argument("--max-len", type=int, default=256)
    ap.add_argument("--threshold", type=float, default=0.5)
    ap.add_argument("--out", default="results")
    a = ap.parse_args(argv)

    df = get_dataframe(a.data, a.synthetic, a.text_col, a.label_col)
    _, _, test = split(df)
    prob = load_predictor(a.weights, a.max_len)(test["narrative"])
    pred = (prob >= a.threshold).astype(int)
    name = a.name or os.path.splitext(os.path.basename(a.weights.rstrip("/")))[0]
    metrics = save_evaluation(name, test["fraud"].values, pred, prob, test["narrative"].values, a.out, a.threshold)
    print(f"{len(test)} test claims ({int(test['fraud'].sum())} fraud)")
    for k, v in metrics.items():
        print(f"  {k}: {v:.4f}")


if __name__ == "__main__":
    main()
