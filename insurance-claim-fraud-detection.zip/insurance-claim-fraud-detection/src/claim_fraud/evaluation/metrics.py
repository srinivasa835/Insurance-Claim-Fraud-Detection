"""Metrics and plots. Output layout (under `out_dir`, default `results/`):

    training/           <name>_curves.png, <name>_history.csv
    evaluation/         confusion matrices, PR / ROC / F1-threshold curves
    metrics/            <name>_test_metrics.json
    sample_predictions/ <name>_sample_predictions.csv
"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.metrics import (accuracy_score, average_precision_score, classification_report,
                             confusion_matrix, f1_score, precision_recall_curve,
                             precision_score, recall_score, roc_auc_score, roc_curve)

LABELS = ["genuine", "fraud"]


def _sub(out_dir, name):
    path = os.path.join(out_dir, name)
    os.makedirs(path, exist_ok=True)
    return path


def compute_metrics(y_true, y_pred, y_prob=None):
    out = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
    }
    if y_prob is not None and len(set(y_true)) > 1:
        out["roc_auc"] = float(roc_auc_score(y_true, y_prob))
        out["average_precision"] = float(average_precision_score(y_true, y_prob))
    return out


def plot_curves(history, name, out_dir="results"):
    """history: dict of equal-length lists train_loss, val_loss, train_acc, val_acc."""
    d = _sub(out_dir, "training")
    pd.DataFrame(history).rename_axis("epoch").reset_index().assign(
        epoch=lambda f: f["epoch"] + 1).to_csv(os.path.join(d, f"{name}_history.csv"), index=False)
    x = range(1, len(history["train_loss"]) + 1)
    fig, ax = plt.subplots(1, 2, figsize=(9, 3.6))
    for a, key, title in ((ax[0], "loss", "Loss"), (ax[1], "acc", "Accuracy")):
        a.plot(x, history[f"train_{key}"], marker="o", label="train")
        a.plot(x, history[f"val_{key}"], marker="o", label="validation")
        a.set_title(title)
        a.set_xlabel("Training subset (20% to 100%)" if "learning_curve" in name else "Epoch")
        a.legend()
    fig.suptitle(name); fig.tight_layout()
    fig.savefig(os.path.join(d, f"{name}_curves.png"), dpi=200)
    plt.close(fig)


def _confusion(cm, normalized, name, path):
    plt.figure(figsize=(4.6, 4))
    data = cm / cm.sum(axis=1, keepdims=True).clip(min=1) if normalized else cm
    sns.heatmap(data, annot=True, fmt=".2f" if normalized else "d", cmap="Blues", cbar=False,
                xticklabels=LABELS, yticklabels=LABELS)
    plt.xlabel("Predicted"); plt.ylabel("Actual")
    plt.title(f"{name}: {'normalized ' if normalized else ''}confusion matrix")
    plt.tight_layout(); plt.savefig(path, dpi=200); plt.close()


def save_evaluation(name, y_true, y_pred, y_prob, texts, out_dir="results", threshold=0.5):
    """Write all test-split artefacts and return the metrics dict."""
    y_true, y_pred, y_prob = np.asarray(y_true), np.asarray(y_pred), np.asarray(y_prob)
    ev, mt, sp = _sub(out_dir, "evaluation"), _sub(out_dir, "metrics"), _sub(out_dir, "sample_predictions")

    metrics = compute_metrics(y_true, y_pred, y_prob)
    report = classification_report(y_true, y_pred, target_names=LABELS, output_dict=True, zero_division=0)
    with open(os.path.join(mt, f"{name}_test_metrics.json"), "w") as f:
        json.dump({"model": name, "n_test": int(len(y_true)), "n_fraud": int(y_true.sum()),
                   "threshold": threshold, "overall": metrics, "per_class": {k: report[k] for k in LABELS}},
                  f, indent=2)

    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    _confusion(cm, False, name, os.path.join(ev, f"{name}_confusion_matrix.png"))
    _confusion(cm.astype(float), True, name, os.path.join(ev, f"{name}_confusion_matrix_normalized.png"))

    if len(set(y_true)) > 1:
        p, r, th = precision_recall_curve(y_true, y_prob)
        plt.figure(figsize=(4.6, 4)); plt.plot(r, p)
        plt.xlabel("Recall"); plt.ylabel("Precision"); plt.title(f"{name}: precision-recall")
        plt.tight_layout(); plt.savefig(os.path.join(ev, f"{name}_pr_curve.png"), dpi=200); plt.close()

        fpr, tpr, _ = roc_curve(y_true, y_prob)
        plt.figure(figsize=(4.6, 4)); plt.plot(fpr, tpr, label=f"AUC = {metrics['roc_auc']:.3f}")
        plt.plot([0, 1], [0, 1], "--", color="gray"); plt.legend()
        plt.xlabel("False positive rate"); plt.ylabel("True positive rate"); plt.title(f"{name}: ROC")
        plt.tight_layout(); plt.savefig(os.path.join(ev, f"{name}_roc_curve.png"), dpi=200); plt.close()

        grid = np.linspace(0.05, 0.95, 91)
        f1s = [f1_score(y_true, (y_prob >= t).astype(int), zero_division=0) for t in grid]
        plt.figure(figsize=(4.6, 4)); plt.plot(grid, f1s)
        plt.xlabel("Decision threshold"); plt.ylabel("F1 (fraud)"); plt.title(f"{name}: F1 vs threshold")
        plt.tight_layout(); plt.savefig(os.path.join(ev, f"{name}_f1_threshold_curve.png"), dpi=200); plt.close()

    preds = pd.DataFrame({"narrative": list(texts), "actual": y_true, "predicted": y_pred,
                          "fraud_probability": np.round(y_prob, 4)})
    preds["correct"] = preds["actual"] == preds["predicted"]
    preds.head(50).to_csv(os.path.join(sp, f"{name}_sample_predictions.csv"), index=False)
    return metrics
