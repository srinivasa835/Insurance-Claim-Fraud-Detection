"""Predict fraud probability for new claim narratives.

    claim-infer --weights results/models/tfidf_logreg.joblib --text "My car was destroyed!"
    claim-infer --weights results/models/roberta --source new_claims.csv --text-col narrative
"""
import argparse
import json
import os

import pandas as pd


def load_predictor(weights, max_len=256, batch_size=32):
    """Return predict_fn(list_of_texts) -> numpy array of fraud probabilities.

    `weights` is a .joblib file (TF-IDF model) or a folder saved by train_roberta.
    """
    if os.path.isdir(weights):
        return _roberta_predictor(weights, max_len, batch_size)
    from claim_fraud.models import tfidf_model as T
    bundle = T.load_bundle(weights)
    return lambda texts: T.predict_proba(bundle, list(texts))


def _roberta_predictor(folder, max_len, batch_size):
    import numpy as np
    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    cfg_path = os.path.join(folder, "claim_fraud_config.json")
    if os.path.exists(cfg_path):
        max_len = json.load(open(cfg_path)).get("max_len", max_len)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    tok = AutoTokenizer.from_pretrained(folder)
    model = AutoModelForSequenceClassification.from_pretrained(folder).to(device).eval()

    def predict(texts):
        texts, out = list(texts), []
        with torch.no_grad():
            for i in range(0, len(texts), batch_size):
                enc = tok(texts[i:i + batch_size], truncation=True, padding=True,
                          max_length=max_len, return_tensors="pt").to(device)
                out.extend(torch.softmax(model(**enc).logits, dim=-1)[:, 1].cpu().numpy())
        return np.array(out)

    return predict


def main(argv=None):
    ap = argparse.ArgumentParser(description="Predict fraud probability for claim narratives")
    ap.add_argument("--weights", required=True, help=".joblib file or RoBERTa folder")
    ap.add_argument("--text", help="a single narrative")
    ap.add_argument("--source", help="CSV file with a narrative column")
    ap.add_argument("--text-col", default="narrative")
    ap.add_argument("--max-len", type=int, default=256)
    ap.add_argument("--threshold", type=float, default=0.5)
    ap.add_argument("--out", help="optional CSV path to save predictions")
    a = ap.parse_args(argv)

    if not a.text and not a.source:
        ap.error("Provide --text or --source")
    texts = [a.text] if a.text else pd.read_csv(a.source)[a.text_col].astype(str).tolist()
    probs = load_predictor(a.weights, a.max_len)(texts)
    df = pd.DataFrame({"narrative": texts, "fraud_probability": probs.round(4)})
    df["prediction"] = ["fraud" if p >= a.threshold else "genuine" for p in probs]
    if a.out:
        df.to_csv(a.out, index=False)
    print(df.assign(narrative=df["narrative"].str.slice(0, 70)).to_string(index=False))


if __name__ == "__main__":
    main()
